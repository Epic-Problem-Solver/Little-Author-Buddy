Little Author Buddy supporter packs
Hats: beanie, beret, cap, cowboy, party
Games: Chase the Mouse, Tag the Buddy, Red Light Green Light, High Five, and Hide and Seek

Needs Little Author Buddy 0.8.0. Quit the app, then copy these folders into the packs folder so each one sits directly inside it:

Windows: %APPDATA%\dev.lwc.companion\packs
Mac: ~/Library/Application Support/dev.lwc.companion/packs
Linux: ~/.local/share/dev.lwc.companion/packs

Create the packs folder if it is not there. The folders to copy are beanie, beret, cap, cowboy, party, chase, tag, redlight, highfive, and warmer. Open the app again. The hats are in Settings. The games show up with the focus timer.